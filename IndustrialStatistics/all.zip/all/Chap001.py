## Chapter 1
#
# Industrial Statistics: A Computer Based Approach with Python<br>
# by Ron Kenett, Shelemyahu Zacks, Peter Gedeck
# 
# Publisher: Springer International Publishing; 1st edition (2023) <br>
# <!-- ISBN-13: 978-3031075650 -->
# 
# (c) 2022 Ron Kenett, Shelemyahu Zacks, Peter Gedeck
# 
# The code needs to be executed in sequence.
# The Role of Statistical Methods in Modern Industry
## Evolution of Industry
## Evolution of Quality
## Industry 4.0 Characteristics
## Digital Twin
## Chapter Highlights
## Exercises
